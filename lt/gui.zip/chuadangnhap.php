<?php ob_start();?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<div style="background-color: LightGray;">
	<hr size="1px" color="black"/>
	<p><a href="../index.html"><b>Trang chủ</b></a>&emsp;|&emsp;<a href="./buoi3_bai1.html">Đăng kí</a>&emsp;|&emsp;<a href="./buoi3_bai2.html">Đăng nhập</a></p>
	<hr size="1px" color="black"/>
	<h1>Xin chào vui lòng đăng nhập để tiếp tục!</h1>
	</div>
</body>
</html>