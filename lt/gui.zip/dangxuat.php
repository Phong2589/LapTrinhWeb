<?php ob_start();?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>dang xuat</title>
</head>

<body>
	<?php 
	session_start();
//	setcookie("username", "", time()-3600000); 
//	setcookie("id","",time()-3600000);
	unset($_SESSION['username']);
	unset($_SESSION['id']);
	header('location:' . "./buoi3.php");
	?>
</body>
</html>